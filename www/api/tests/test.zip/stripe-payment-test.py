# -*- coding: utf-8 -*-
'''
@author Tony Gaitatzis
@organization ReadWrite
@licence MIT
@contact backupbrain@gmail.com
'''


import json
import os
import traceback
import urllib
import requests

import pymysql
from databaseobject.DatabaseObject import DatabaseObject
from LambdaLog import LambdaLog
from settings import settings


def lambda_handler(event, context):
    is_logging_enabled = False
    if os.getenv('IS_LOGGING_ENABLED') == '1':
        is_logging_enabled = True

    http_server = HttpServer(event)
    #print(json.dumps(event, indent=4))


    try:
        database = pymysql.connect(host=settings.mysql['server'],
                                user=settings.mysql['username'],
                                password=settings.mysql['password'],
                                db=settings.mysql['schema'],
                                charset='utf8',
                                cursorclass=pymysql.cursors.DictCursor)


    except:
        message = "Error connecting to database"
        headers = http_server.get_headers()
        headers['response'] = message
        print(message)

        # We don't push an error here, because we want the system to fail gracefully by forwarding the user
        # even if there's a problem connecting to the database
        return http_server.respond_error(message) # Shortcut to forwarding


    database_object = DatabaseObject(database)

    if is_logging_enabled:
        lambda_log = LambdaLog(database_object)
        if 'resource' in event:
            lambda_log.application_id = event['resource']
        lambda_log.endpoint_url = http_server.get_url()
        lambda_log.url_query = json.dumps(http_server.get_query_parameters(), indent=0)
        lambda_log.ip_address = http_server.get_ip()
        lambda_log.forwarding_ip_addresses = http_server.get_forwarded_for()
        lambda_log.cookie_value = http_server.get_cookie_string()
        lambda_log.user_agent = http_server.get_user_agent()
        lambda_log.http_method = http_server.get_method()
        lambda_log.http_headers = json.dumps(http_server.get_headers(), indent=0)
        lambda_log.post_body = http_server.get_post_body()
        #print(json.dumps(dict(lambda_log), indent=4))
        lambda_log.insert()


    if event['httpMethod'] == HttpServer.METHOD_HEAD or event['httpMethod'] == HttpServer.METHOD_OPTIONS:
        message = "HEAD/OPTIONS"
        print(message)
        print(json.dumps(http_server.event, indent=4))


        return http_server.respond("")
    else:
        message = "GET/POST/PUT/etc"
        print(message)
        print(json.dumps(http_server.event, indent=4))

        raw_post_body = http_server.get_post_body()
        if raw_post_body is not None:
            if is_logging_enabled:
                lambda_log.response_code = 500
                lambda_log.response_body = transaction_type
                lambda_log.internal_message = "fullcontact record id: " + str(full_contact.id)
                lambda_log.update()

        output = {
            "status": "success"
        }

        return http_server.respond_ok(output)
